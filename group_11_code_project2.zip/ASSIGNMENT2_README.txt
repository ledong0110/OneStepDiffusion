CE6190 Assignment 2 - Group 11

Report source: report/assignment2.tex
Tables, measured metrics and native-model figures are included.
Compile without Python, datasets or model checkpoints:
  cd report
  latexmk -pdf -outdir=build assignment2.tex

The PDF submission is supplied separately. Original datasets and model
weights are intentionally excluded. Training/evaluation code, configs,
dependency locks, tests and third-party license notices are included.
See README.md for environment setup and experiment commands; see
docs/ASSIGNMENT2_REQUIREMENTS.md for the assignment coverage.
Full asset regeneration requires the native completed evaluation JSONs;
the included assets suffice to compile the submitted report offline.
